# Practice Quiz: Before Version Control

### 1.Your colleague sent you a patch called fix_names.patch, which fixes a config file called fix_names.conf. What command do you need to run to apply the patch to the config file?

    patch fix_names.conf < fix_names.patch

### 2.You're helping a friend with a bug in a script called fix_permissions.py, which fixes the permissions of a bunch of files. To work on the file, you make a copy and call it fix_permissions_modified.py. What command do you need to run after solving the bug to send the patch to your friend?

    diff fix_permissions.py fix_permissions_modified.py > fix_permissions.patch

### 3.The _____ commandhighlights the words that changed in a file instead of working line by line.

    vimdiff

### 4.How can we choose the return value our script returns when it finishes?

    Using the exit command from the sys module

### 5. In addition to the original files, what else do we need before we can use the patch command?

    Diff file
